function [ histogram ] = gradientHistogram(vertical_derivative, horizontal_derivative)
%places each gradient into one of eight orientation bins.
bins = atan2(horizontal_derivative, vertical_derivative);
histogram = zeros(8,1); % initialization
% each orientation is the summation of gradients in that area
histogram(1) = norm(bins((bins>=0)&(bins<=pi/4)));
histogram(2) = norm(bins((bins>pi/4)&(bins<=pi/2)));
histogram(3) = norm(bins((bins>pi/2)&(bins<=3*pi/4)));
histogram(4) = norm(bins((bins>3*pi/4)&(bins<=pi)));
histogram(5) = norm(bins((bins>=-pi)&(bins<-3*pi/4)));
histogram(6) = norm(bins((bins>=-3*pi/4)&(bins<-pi/2)));
histogram(7) = norm(bins((bins>=-pi/2)&(bins<-pi/4)));
histogram(8) = norm(bins((bins>=-pi/4)&(bins<0)));
% histogram = abs(histogram);

end

